module.exports = (req, res, next) => {
  const token = req.headers.authorization;

  if (token !== "Bearer mysecrettoken") {
    return res.status(401).json({ message: "Unauthorized" });
  }

  next();
};